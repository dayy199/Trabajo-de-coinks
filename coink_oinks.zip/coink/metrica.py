"""Score Coink: métrica para evaluar qué tan buenos son los usuarios de los Oinks."""
import numpy as np
import pandas as pd

PESOS = {"ahorro": 0.35, "frecuencia": 0.25, "constancia": 0.25, "recencia": 0.15}
CATEGORIAS = [(0, "Ocasional"), (30, "Regular"), (50, "Bueno"), (70, "Excelente")]
ORDEN_CAT = [c for _, c in CATEGORIAS]


def cargar(ruta):
    df = pd.read_csv(ruta, parse_dates=["operation_date", "user_createddate"])
    df = df.drop(columns=[c for c in df.columns if c.startswith("Unnamed")])
    df = df.rename(columns={"operation_value": "monto", "operation_date": "fecha",
                            "maplocation_name": "oink", "user_createddate": "creado"})
    df["oink"] = df["oink"].str.strip()
    return df.sort_values(["user_id", "fecha"]).reset_index(drop=True)


def categorizar(score):
    cat = ORDEN_CAT[0]
    for umbral, nombre in CATEGORIAS:
        if score >= umbral:
            cat = nombre
    return cat


def calcular_scores(df, pesos=PESOS):
    corte = df["fecha"].max()
    inicio = df["fecha"].min()
    df = df.assign(dia=df["fecha"].dt.normalize(), semana=df["fecha"].dt.to_period("W"))

    u = df.groupby("user_id").agg(
        n_depositos=("monto", "size"), total=("monto", "sum"), mediana=("monto", "median"),
        dias_activos=("dia", "nunique"), semanas_activas=("semana", "nunique"),
        primera=("fecha", "min"), ultima=("fecha", "max"), creado=("creado", "first"),
        n_oinks=("oink", "nunique"))

    # Semanas en las que el usuario pudo haber depositado (mínimo 4 para no inflar a los nuevos)
    desde = u["creado"].clip(lower=inicio)
    semanas_disp = np.ceil((corte - desde).dt.days / 7).clip(lower=4)
    u["recencia_dias"] = (corte - u["ultima"]).dt.days

    comp = pd.DataFrame(index=u.index)
    comp["ahorro"] = u["total"].rank(pct=True)
    comp["frecuencia"] = u["dias_activos"].rank(pct=True)
    comp["constancia"] = (u["semanas_activas"] / semanas_disp).clip(upper=1)
    comp["recencia"] = np.exp(-u["recencia_dias"] / 30)
    comp = comp * 100
    comp.columns = [f"c_{c}" for c in comp.columns]

    u = u.join(comp)
    u["score"] = sum(pesos[k] * u[f"c_{k}"] for k in pesos) / sum(pesos.values())
    u["categoria"] = pd.Categorical(u["score"].map(categorizar), categories=ORDEN_CAT, ordered=True)
    return u.sort_values("score", ascending=False).reset_index()
