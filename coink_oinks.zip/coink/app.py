import pandas as pd
import streamlit as st

import graficas
from metrica import PESOS, ORDEN_CAT, cargar, calcular_scores

st.set_page_config(page_title="Score Coink", layout="wide")


@st.cache_data
def datos():
    return cargar("data/depositos_oinks.csv")


df = datos()

st.title("Score Coink: ¿qué tan buenos son los usuarios de los Oinks?")
st.write(
    "Cada usuario recibe un puntaje de 0 a 100 que combina cuánto ahorra, con qué frecuencia, "
    "qué tan constante es semana a semana y qué tan reciente es su último depósito."
)

st.sidebar.header("Pesos de la métrica")
w = {k: st.sidebar.slider(k.capitalize(), 0, 100, int(v * 100), 5) for k, v in PESOS.items()}
if sum(w.values()) == 0:
    st.sidebar.error("Al menos un peso debe ser mayor que 0.")
    st.stop()
oinks = st.sidebar.multiselect("Oinks", sorted(df["oink"].unique()), default=sorted(df["oink"].unique()))
df_f = df[df["oink"].isin(oinks)]
if df_f.empty:
    st.warning("Selecciona al menos un Oink.")
    st.stop()

u = calcular_scores(df_f, pesos={k: v / 100 for k, v in w.items()})

c1, c2, c3, c4 = st.columns(4)
c1.metric("Usuarios", f"{len(u):,}")
c2.metric("Depósitos", f"{len(df_f):,}")
c3.metric("Monto total (COP)", f"{df_f['monto'].sum():,.0f}")
c4.metric("Score promedio", f"{u['score'].mean():.1f}")

tab1, tab2, tab3 = st.tabs(["Métrica", "Actividad", "Buscar usuario"])

with tab1:
    st.markdown(
        "**Componentes (0-100):** ahorro total y días activos se miden como percentil frente a los demás usuarios; "
        "constancia es la fracción de semanas con depósito; recencia decae con 30 días de vida media."
    )
    a, b = st.columns(2)
    a.pyplot(graficas.hist_score(u))
    b.pyplot(graficas.componentes_por_categoria(u, {k: v / 100 for k, v in w.items()}))
    a, b = st.columns(2)
    a.pyplot(graficas.dispersion(u))
    b.pyplot(graficas.caja_monto(u))
    resumen = u.groupby("categoria", observed=True).agg(
        usuarios=("user_id", "size"), depositos_mediana=("n_depositos", "median"),
        ahorro_mediano=("total", "median"), score_medio=("score", "mean")).round(1)
    st.dataframe(resumen.reindex(ORDEN_CAT))

with tab2:
    a, b = st.columns(2)
    a.pyplot(graficas.serie_semanal(df_f))
    b.pyplot(graficas.por_oink(df_f))

with tab3:
    cat = st.multiselect("Categoría", ORDEN_CAT, default=ORDEN_CAT)
    tabla = u[u["categoria"].isin(cat)][
        ["user_id", "score", "categoria", "n_depositos", "total", "dias_activos", "recencia_dias"]]
    st.dataframe(tabla.round(1), use_container_width=True)
    st.download_button("Descargar usuarios calificados (CSV)", tabla.round(2).to_csv(index=False), "usuarios_calificados.csv")
    if len(tabla):
        elegido = st.selectbox("Ver detalle de un usuario", tabla["user_id"].head(200))
        fila = u[u["user_id"] == elegido].iloc[0]
        st.metric(f"Score ({fila['categoria']})", f"{fila['score']:.1f}")
        st.pyplot(graficas.componentes_usuario(fila, {k: v / 100 for k, v in w.items()}))
