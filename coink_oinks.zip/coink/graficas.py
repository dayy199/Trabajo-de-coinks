"""Funciones de gráficas (Matplotlib) usadas por la app y por el script de exportación."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from metrica import ORDEN_CAT, PESOS

COLORES = {"Ocasional": "#B4B2A9", "Regular": "#85B7EB", "Bueno": "#1D9E75", "Excelente": "#D85A30"}


def hist_score(u):
    fig, ax = plt.subplots(figsize=(7, 4))
    bins = np.linspace(0, 100, 26)
    for cat in ORDEN_CAT:
        ax.hist(u.loc[u["categoria"] == cat, "score"], bins=bins, color=COLORES[cat], label=cat)
    ax.set_xlabel("Score Coink (0-100)")
    ax.set_ylabel("Número de usuarios")
    ax.set_title("Distribución del score por categoría")
    ax.legend()
    fig.tight_layout()
    return fig


def dispersion(u):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for cat in ORDEN_CAT:
        s = u[u["categoria"] == cat]
        ax.scatter(s["dias_activos"], s["total"], s=18, alpha=0.6, color=COLORES[cat], label=cat)
    ax.set_yscale("log")
    ax.set_xlabel("Días con al menos un depósito")
    ax.set_ylabel("Total ahorrado (COP, escala log)")
    ax.set_title("Frecuencia vs. monto ahorrado")
    ax.legend()
    fig.tight_layout()
    return fig


def caja_monto(u):
    fig, ax = plt.subplots(figsize=(7, 4))
    datos = [u.loc[u["categoria"] == c, "total"] for c in ORDEN_CAT]
    bp = ax.boxplot(datos, tick_labels=ORDEN_CAT, patch_artist=True, showfliers=False)
    for patch, c in zip(bp["boxes"], ORDEN_CAT):
        patch.set_facecolor(COLORES[c])
    ax.set_yscale("log")
    ax.set_ylabel("Total ahorrado (COP, escala log)")
    ax.set_title("Ahorro total por categoría")
    fig.tight_layout()
    return fig


def componentes_por_categoria(u, pesos=PESOS):
    fig, ax = plt.subplots(figsize=(7, 4))
    g = u.groupby("categoria", observed=True)[[f"c_{k}" for k in pesos]].mean()
    g = g.mul([pesos[k] / sum(pesos.values()) for k in pesos], axis=1)
    bottom = np.zeros(len(g))
    tonos = ["#534AB7", "#1D9E75", "#D85A30", "#BA7517"]
    for (col, tono) in zip(g.columns, tonos):
        ax.bar(g.index.astype(str), g[col], bottom=bottom, label=col[2:].capitalize(), color=tono)
        bottom += g[col].values
    ax.set_ylabel("Aporte promedio al score")
    ax.set_title("De dónde viene el score de cada categoría")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


def serie_semanal(df):
    s = df.set_index("fecha").resample("W")
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(s.size().index, s.size().values, width=5, color="#1D9E75")
    ax.set_ylabel("Depósitos por semana", color="#1D9E75")
    ax2 = ax.twinx()
    ax2.plot(s["monto"].sum().index, s["monto"].sum().values / 1e6, color="#D85A30", marker="o", ms=3)
    ax2.set_ylabel("Monto semanal (millones COP)", color="#D85A30")
    ax.set_title("Actividad semanal de los Oinks")
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def por_oink(df):
    g = df.groupby("oink").agg(depositos=("monto", "size"), usuarios=("user_id", "nunique"))
    fig, ax = plt.subplots(figsize=(7, 3.5))
    y = np.arange(len(g))
    ax.barh(y - 0.2, g["depositos"], height=0.4, label="Depósitos", color="#534AB7")
    ax.barh(y + 0.2, g["usuarios"], height=0.4, label="Usuarios únicos", color="#85B7EB")
    ax.set_yticks(y, g.index)
    ax.set_title("Uso por Oink")
    ax.legend()
    fig.tight_layout()
    return fig


def componentes_usuario(fila, pesos=PESOS):
    fig, ax = plt.subplots(figsize=(6, 3))
    nombres = [k.capitalize() for k in pesos]
    vals = [fila[f"c_{k}"] for k in pesos]
    ax.barh(nombres, vals, color="#534AB7")
    ax.set_xlim(0, 100)
    ax.set_xlabel("Puntaje del componente (0-100)")
    ax.invert_yaxis()
    fig.tight_layout()
    return fig


def todas(u, df):
    return {"01_hist_score": hist_score(u), "02_dispersion": dispersion(u), "03_caja_monto": caja_monto(u),
            "04_componentes": componentes_por_categoria(u), "05_serie_semanal": serie_semanal(df),
            "06_por_oink": por_oink(df)}
