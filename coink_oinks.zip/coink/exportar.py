"""Genera usuarios_calificados.csv y las gráficas PNG a partir del CSV de depósitos."""
from metrica import cargar, calcular_scores
import graficas

df = cargar("data/depositos_oinks.csv")
u = calcular_scores(df)
cols = ["user_id", "score", "categoria", "n_depositos", "total", "dias_activos", "semanas_activas",
        "recencia_dias", "n_oinks", "c_ahorro", "c_frecuencia", "c_constancia", "c_recencia"]
u[cols].round(2).to_csv("usuarios_calificados.csv", index=False)
for nombre, fig in graficas.todas(u, df).items():
    fig.savefig(f"graficas/{nombre}.png", dpi=130)
print(u["categoria"].value_counts().sort_index())
