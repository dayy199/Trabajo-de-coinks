# Score Coink

Métrica para calificar a los usuarios de los Oinks a partir de `data/depositos_oinks.csv`
(4.345 depósitos, 1.656 usuarios, 26-nov-2021 a 24-feb-2022, 3 Oinks).

## Score (0-100)
| Componente | Definición | Peso |
|---|---|---|
| Ahorro | Percentil del total depositado | 35 % |
| Frecuencia | Percentil de días con depósito | 25 % |
| Constancia | Semanas con depósito / semanas disponibles (mínimo 4) | 25 % |
| Recencia | exp(-días desde el último depósito / 30) | 15 % |

Categorías: Ocasional (<30), Regular (30-50), Bueno (50-70), Excelente (≥70).

## Uso
```
pip install -r requirements.txt
python exportar.py        # genera usuarios_calificados.csv y graficas/*.png
streamlit run app.py
```
Despliegue: subir el repositorio a GitHub (público) y conectarlo en https://share.streamlit.io.
